# AI Automation Framework 🤖
This project integrates AI tools (ChatGPT/Perplexity) for generating test cases dynamically.

## Features
- Auto-generate test cases from natural language requirements
- Run test cases using **PyTest + Selenium**
- Export execution reports in HTML

## Tech Stack
- Python
- OpenAI API
- PyTest
- Selenium
