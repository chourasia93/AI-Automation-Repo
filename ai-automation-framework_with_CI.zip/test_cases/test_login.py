import pytest
from selenium import webdriver

def test_login():
    driver = webdriver.Chrome()
    driver.get("https://example.com/login")
    driver.find_element("id", "username").send_keys("testuser")
    driver.find_element("id", "password").send_keys("password123")
    driver.find_element("css selector", "button[type='submit']").click()
    assert "Welcome" in driver.page_source
    driver.quit()
